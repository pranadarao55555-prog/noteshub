import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { supabase, isSupabaseConfigured } from '../config/supabase';
import { useAuth } from './AuthContext';
import type { PresenceUser } from '../types';

interface PresenceContextType {
  onlineUsers: PresenceUser[];
  onlineCount: number;
  isPresenceDrawerOpen: boolean;
  setPresenceDrawerOpen: (open: boolean) => void;
  updateCurrentNoteViewing: (noteId?: string, noteTitle?: string) => void;
  simulateClassmatePresence: (name?: string, noteTitle?: string) => void;
}

const PresenceContext = createContext<PresenceContextType | undefined>(undefined);

const SAMPLE_COHORT_NAMES = [
  'Aarav Sharma (Roll 07)',
  'Priya Patel (Roll 14)',
  'Dev Mehta (Roll 23)',
  'Ananya Iyer (Roll 38)',
  'Kavya Reddy (Roll 45)',
  'Siddharth Verma (Roll 51)',
  'Neha Gupta (Roll 62)',
  'Aditya Rao (Roll 74)',
];

export const PresenceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [onlineUsers, setOnlineUsers] = useState<PresenceUser[]>([]);
  const [isPresenceDrawerOpen, setPresenceDrawerOpen] = useState(false);
  const channelRef = useRef<any>(null);

  const currentPresenceRef = useRef<PresenceUser | null>(null);

  useEffect(() => {
    if (!currentUser) {
      setOnlineUsers([]);
      return;
    }

    const selfPresence: PresenceUser = {
      uid: currentUser.uid,
      displayName: currentUser.displayName,
      email: currentUser.email,
      photoURL: currentUser.photoURL || '',
      joinedAt: Date.now(),
      lastActive: Date.now(),
    };
    currentPresenceRef.current = selfPresence;

    if (isSupabaseConfigured) {
      // Supabase Realtime Presence Channel: 'online-cohort'
      const channel = supabase.channel('online-cohort', {
        config: {
          presence: {
            key: currentUser.uid,
          },
        },
      });

      channelRef.current = channel;

      channel
        .on('presence', { event: 'sync' }, () => {
          const state = channel.presenceState();
          const usersMap = new Map<string, PresenceUser>();

          Object.values(state).forEach((presences: any) => {
            presences.forEach((p: PresenceUser) => {
              if (p && p.uid) {
                usersMap.set(p.uid, p);
              }
            });
          });

          const list = Array.from(usersMap.values());
          // STRICT SORTING: The most recently joined user appears at the TOP
          list.sort((a, b) => (b.joinedAt || 0) - (a.joinedAt || 0));
          setOnlineUsers(list);
        })
        .subscribe(async (status) => {
          if (status === 'SUBSCRIBED') {
            await channel.track(selfPresence);
          }
        });

      return () => {
        if (channelRef.current) {
          channelRef.current.untrack().catch(() => {});
          supabase.removeChannel(channelRef.current);
          channelRef.current = null;
        }
      };
    } else {
      // Local fallback for offline / mock testing
      const channelName = 'noteshub_presence_channel';
      let bc: BroadcastChannel | null = null;
      try {
        bc = new BroadcastChannel(channelName);
      } catch {
        // ignore
      }

      setOnlineUsers([selfPresence]);

      return () => {
        if (bc) bc.close();
      };
    }
  }, [currentUser]);

  const updateCurrentNoteViewing = useCallback((noteId?: string, noteTitle?: string) => {
    if (!currentUser) return;

    if (currentPresenceRef.current) {
      currentPresenceRef.current.currentNoteId = noteId;
      currentPresenceRef.current.currentNoteTitle = noteTitle;
      currentPresenceRef.current.lastActive = Date.now();
    }

    if (channelRef.current && isSupabaseConfigured) {
      channelRef.current.track(currentPresenceRef.current).catch((err: any) => {
        console.warn('Error tracking Supabase presence update:', err);
      });
    } else {
      setOnlineUsers((prev) =>
        prev.map((u) =>
          u.uid === currentUser.uid
            ? { ...u, currentNoteId: noteId, currentNoteTitle: noteTitle }
            : u
        )
      );
    }
  }, [currentUser]);

  const simulateClassmatePresence = useCallback((name?: string, noteTitle?: string) => {
    const randomIdx = Math.floor(Math.random() * SAMPLE_COHORT_NAMES.length);
    const chosenName = name || SAMPLE_COHORT_NAMES[randomIdx];
    const rollMatch = chosenName.match(/\d+/);
    const roll = rollMatch ? rollMatch[0] : Math.floor(Math.random() * 76 + 1);
    const mockEmail = `student${roll}@univ.edu`;
    const simId = 'simulated_' + Date.now();

    const simulatedUser: PresenceUser = {
      uid: simId,
      displayName: chosenName,
      email: mockEmail,
      photoURL: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(chosenName)}`,
      joinedAt: Date.now(), // Newly joined! Appears at TOP
      lastActive: Date.now(),
      currentNoteTitle: noteTitle || undefined,
    };

    setOnlineUsers((prev) => [simulatedUser, ...prev.filter((u) => u.uid !== simId)]);
  }, []);

  return (
    <PresenceContext.Provider
      value={{
        onlineUsers,
        onlineCount: onlineUsers.length,
        isPresenceDrawerOpen,
        setPresenceDrawerOpen,
        updateCurrentNoteViewing,
        simulateClassmatePresence,
      }}
    >
      {children}
    </PresenceContext.Provider>
  );
};

export const usePresence = () => {
  const context = useContext(PresenceContext);
  if (!context) {
    throw new Error('usePresence must be used within a PresenceProvider');
  }
  return context;
};
