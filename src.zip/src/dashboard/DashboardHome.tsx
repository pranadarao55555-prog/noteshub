import { useState, useEffect, useMemo } from 'react';
import { useAuth, isEmailAdmin } from '../auth/AuthProvider';
import './dashboard.css';
import SavedNotes from './existing/SavedNotes';
import NotebookShelves from './existing/NotebookShelves';
import LatestUploads from './existing/LatestUploads';
import ClassUpdates from './existing/ClassUpdates';
import AdminPanel from '../admin/AdminPanel';
import { DrmPdfReader } from '../components/Reader/DrmPdfReader';
import { GeminiAssistantDrawer } from '../components/AI/GeminiAssistantDrawer';
import { OnlineClassmatesDrawer } from '../components/Presence/OnlineClassmatesDrawer';
import { subscribeToNotes, deleteNote } from '../services/notesService';
import type { Note } from '../types';

export default function DashboardHome() {
  const { access, user, logout } = useAuth();
  const isAdmin = access === 'admin' || isEmailAdmin(user?.email);

  const [notes, setNotes] = useState<Note[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeNote, setActiveNote] = useState<Note | null>(null);
  const [activePage, setActivePage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [isGeminiOpen, setGeminiOpen] = useState(false);

  // Sync notes from database
  useEffect(() => {
    const unsub = subscribeToNotes((list) => {
      setNotes(list);
    });

    const handleNotesUpdated = () => {
      subscribeToNotes(setNotes);
    };
    window.addEventListener('nh:notes-updated', handleNotesUpdated);

    return () => {
      unsub();
      window.removeEventListener('nh:notes-updated', handleNotesUpdated);
    };
  }, []);

  const handleOpenNote = (note: Note) => {
    setActiveNote(note);
    setActivePage(1);
    setTotalPages(note.totalPages || 1);
  };

  const handleCloseNote = () => {
    setActiveNote(null);
    setGeminiOpen(false);
  };

  const handleDeleteNote = async (note: Note) => {
    if (!isAdmin) return;
    if (window.confirm(`Permanently delete "${note.title}"?`)) {
      try {
        await deleteNote(note);
        setNotes((prev) => prev.filter((n) => n.id !== note.id));
        if (activeNote?.id === note.id) {
          handleCloseNote();
        }
      } catch (err: any) {
        alert(err.message || 'Failed to delete note');
      }
    }
  };

  // Filter notes by search
  const filteredNotes = useMemo(() => {
    if (!searchQuery.trim()) return notes;
    const q = searchQuery.toLowerCase().trim();
    return notes.filter((n) =>
      n.title.toLowerCase().includes(q) ||
      n.subject.toLowerCase().includes(q) ||
      n.unit.toLowerCase().includes(q) ||
      (n.description && n.description.toLowerCase().includes(q))
    );
  }, [notes, searchQuery]);

  return (
    <div className="nh-dash dash">
      <header className="dash-top">
        <h1 className="nh-logo">notes<span className="nh-dot" /></h1>
        <nav className="dash-nav" aria-label="Main">
          <a className="pill pill-sm is-active" href="/">Home</a>
          <a className="pill pill-sm pill-ghost" href="#explore" onClick={(e) => { e.preventDefault(); }}>Explore</a>
          <a className="pill pill-sm pill-ghost" href="#saves" onClick={(e) => { e.preventDefault(); }}>Saves</a>
          <a className="pill pill-sm pill-ghost" href="#class" onClick={(e) => { e.preventDefault(); }}>My Class</a>
          {isAdmin && <AdminPanel.Trigger />}
          <button className="pill pill-sm pill-ghost" onClick={logout}>Sign out</button>
        </nav>
      </header>

      <div className="dash-search">
        <input
          className="field"
          placeholder="Search subjects, topics, or chapters..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <section className="dash-banner glass-card" aria-label="Welcome">
        <span aria-hidden="true">🎆</span>
        <strong>WELCOME! YOU’RE IN!</strong>
        <span aria-hidden="true">🎆</span>
      </section>

      <main className="dash-grid">
        <section className="glass-card dash-panel">
          <h2>My Saved Notes</h2>
          <SavedNotes notes={notes} onOpenNote={handleOpenNote} />
        </section>

        <section className="glass-card dash-panel">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
            <h2 style={{ margin: 0 }}>Notebook Shelves</h2>
            <span className="nh-dim" style={{ fontSize: 13 }}>
              {filteredNotes.length} note{filteredNotes.length === 1 ? '' : 's'} available
            </span>
          </div>
          <NotebookShelves
            notes={filteredNotes}
            onOpenNote={handleOpenNote}
            onDeleteNote={handleDeleteNote}
          />
        </section>

        <aside className="dash-side">
          <section className="glass-card dash-panel">
            <h2>Latest Uploads</h2>
            <LatestUploads notes={notes} onOpenNote={handleOpenNote} />
          </section>

          <section className="glass-card dash-panel">
            <h2>Class updates</h2>
            <ClassUpdates />
          </section>
        </aside>
      </main>

      {/* Rendered ONLY for admin: not hidden by CSS, absent from the DOM for students */}
      {isAdmin && (
        <AdminPanel.ErrorBoundary>
          <AdminPanel.Upload />
          <AdminPanel.Drawer />
        </AdminPanel.ErrorBoundary>
      )}

      {/* Strict DRM Canvas Streaming Reader Modal */}
      {activeNote && (
        <DrmPdfReader
          note={activeNote}
          onClose={handleCloseNote}
          onOpenGemini={() => setGeminiOpen(true)}
          onPageChange={(curr, total) => {
            setActivePage(curr);
            setTotalPages(total);
          }}
        />
      )}

      {/* Gemini AI Study Assistant Floating Slide-out Drawer */}
      <GeminiAssistantDrawer
        isOpen={isGeminiOpen}
        onClose={() => setGeminiOpen(false)}
        currentNote={activeNote}
        currentPage={activePage}
        totalPages={totalPages}
      />

      {/* Online Classmates Realtime Drawer */}
      <OnlineClassmatesDrawer />
    </div>
  );
}
