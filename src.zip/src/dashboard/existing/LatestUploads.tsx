import { FileText, Clock, ExternalLink } from 'lucide-react';
import type { Note } from '../../types';

interface LatestUploadsProps {
  notes?: Note[];
  onOpenNote?: (note: Note) => void;
}

export default function LatestUploads({ notes = [], onOpenNote }: LatestUploadsProps) {
  if (notes.length === 0) {
    return (
      <div className="nh-dim" style={{ textAlign: 'center', padding: '24px 8px' }}>
        <p style={{ margin: 0, fontSize: 13 }}>No recent uploads found.</p>
      </div>
    );
  }

  return (
    <div style={{ display: 'grid', gap: 10 }}>
      {notes.slice(0, 5).map((note) => {
        const timeStr = new Date(note.uploadedAt).toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
        });

        return (
          <div
            key={note.id}
            className="feed-item"
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: 10,
              cursor: 'pointer',
              transition: 'background .15s ease',
            }}
            onClick={() => onOpenNote && onOpenNote(note)}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 8,
                  background: note.isLabRecord ? 'rgba(80,200,140,.18)' : 'rgba(91,91,214,.2)',
                  border: '1px solid var(--glass-edge)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: note.isLabRecord ? '#70f0b0' : '#8b7bff',
                  flexShrink: 0,
                }}
              >
                <FileText style={{ width: 16, height: 16 }} />
              </div>

              <div style={{ minWidth: 0 }}>
                <strong
                  style={{
                    display: 'block',
                    fontSize: 13,
                    color: '#fff',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {note.title}
                </strong>
                <span className="nh-dim" style={{ fontSize: 11 }}>
                  {note.subject} • {note.unit}
                </span>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
              <span className="nh-dim" style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 3 }}>
                <Clock style={{ width: 11, height: 11 }} /> {timeStr}
              </span>
              <ExternalLink style={{ width: 13, height: 13, color: '#8b7bff', opacity: 0.7 }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}
