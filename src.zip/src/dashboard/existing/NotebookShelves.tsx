import React, { useState, useEffect } from 'react';
import { BookOpen, Bookmark, Trash2, Layers } from 'lucide-react';
import { useAuth } from '../../auth/AuthProvider';
import type { Note } from '../../types';

interface NotebookShelvesProps {
  notes?: Note[];
  onOpenNote?: (note: Note) => void;
  onDeleteNote?: (note: Note) => void;
}

export default function NotebookShelves({
  notes = [],
  onOpenNote,
  onDeleteNote,
}: NotebookShelvesProps) {
  const { access } = useAuth();
  const isAdmin = access === 'admin';

  const [savedIds, setSavedIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem('nh_saved_notes');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    const handleUpdate = () => {
      try {
        const raw = localStorage.getItem('nh_saved_notes');
        setSavedIds(raw ? JSON.parse(raw) : []);
      } catch {
        setSavedIds([]);
      }
    };
    window.addEventListener('nh:saved-notes-updated', handleUpdate);
    return () => window.removeEventListener('nh:saved-notes-updated', handleUpdate);
  }, []);

  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedIds.includes(id)
      ? savedIds.filter((item) => item !== id)
      : [...savedIds, id];
    setSavedIds(updated);
    localStorage.setItem('nh_saved_notes', JSON.stringify(updated));
    window.dispatchEvent(new Event('nh:saved-notes-updated'));
  };

  if (notes.length === 0) {
    return (
      <div className="nh-dim" style={{ textAlign: 'center', padding: '48px 16px' }}>
        <Layers style={{ width: 36, height: 36, margin: '0 auto 10px', opacity: 0.4 }} />
        <p style={{ margin: 0, fontWeight: 600 }}>No notebooks on shelf yet.</p>
        <span style={{ fontSize: 13 }}>Uploaded course notes will be organized here in a 2x2 grid.</span>
      </div>
    );
  }

  // Display notes in a 2x2 shelf grid
  return (
    <div className="shelf-grid">
      {notes.slice(0, 8).map((note) => {
        const isSaved = savedIds.includes(note.id);

        return (
          <div
            key={note.id}
            className="shelf-item"
            style={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: 12,
              minHeight: 140,
            }}
          >
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                <span
                  style={{
                    fontSize: 10,
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    padding: '3px 8px',
                    borderRadius: 6,
                    background: note.isLabRecord ? 'rgba(80,200,140,.18)' : 'rgba(139,123,255,.18)',
                    color: note.isLabRecord ? '#70f0b0' : '#b0a4ff',
                    border: '1px solid rgba(255,255,255,.1)',
                  }}
                >
                  {note.subject}
                </span>

                <span
                  style={{
                    fontSize: 11,
                    fontWeight: 600,
                    color: '#ffd37a',
                    background: 'rgba(255,211,122,.12)',
                    padding: '2px 7px',
                    borderRadius: 6,
                    fontFamily: 'monospace',
                  }}
                >
                  {note.unit}
                </span>
              </div>

              <h3
                style={{
                  margin: '0 0 4px',
                  fontSize: 15,
                  fontWeight: 700,
                  color: '#fff',
                  cursor: 'pointer',
                  lineHeight: 1.3,
                  display: '-webkit-box',
                  WebkitLineClamp: 2,
                  WebkitBoxOrient: 'vertical',
                  overflow: 'hidden',
                }}
                onClick={() => onOpenNote && onOpenNote(note)}
              >
                {note.title}
              </h3>

              <div className="nh-dim" style={{ fontSize: 12 }}>
                {note.fileSizeFormatted} • {note.semester || 'Sem 6'}
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 6, paddingTop: 8, borderTop: '1px solid var(--glass-edge)' }}>
              <div style={{ display: 'flex', gap: 6 }}>
                <button
                  className="pill pill-sm pill-primary"
                  onClick={() => onOpenNote && onOpenNote(note)}
                >
                  <BookOpen style={{ width: 13, height: 13, marginRight: 4 }} /> Read
                </button>

                <button
                  className={`pill pill-sm ${isSaved ? 'pill-ok' : 'pill-ghost'}`}
                  onClick={(e) => toggleBookmark(note.id, e)}
                >
                  <Bookmark style={{ width: 13, height: 13, marginRight: 4, fill: isSaved ? 'currentColor' : 'none' }} />
                  {isSaved ? 'Saved' : 'Bookmark'}
                </button>
              </div>

              {/* ADMIN ONLY: Delete button */}
              {isAdmin && onDeleteNote && (
                <button
                  className="pill pill-sm pill-no"
                  title="Delete note (Admin only)"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteNote(note);
                  }}
                  style={{ padding: '7px 9px' }}
                >
                  <Trash2 style={{ width: 13, height: 13 }} />
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
