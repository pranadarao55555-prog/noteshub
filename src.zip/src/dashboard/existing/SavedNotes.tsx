import { useState, useEffect } from 'react';
import { Bookmark, FileText, BookOpen, Trash2 } from 'lucide-react';
import type { Note } from '../../types';

interface SavedNotesProps {
  notes?: Note[];
  onOpenNote?: (note: Note) => void;
}

export default function SavedNotes({ notes = [], onOpenNote }: SavedNotesProps) {
  const [savedIds, setSavedIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem('nh_saved_notes');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    const handleUpdate = () => {
      try {
        const raw = localStorage.getItem('nh_saved_notes');
        setSavedIds(raw ? JSON.parse(raw) : []);
      } catch {
        setSavedIds([]);
      }
    };
    window.addEventListener('nh:saved-notes-updated', handleUpdate);
    return () => window.removeEventListener('nh:saved-notes-updated', handleUpdate);
  }, []);

  const removeBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedIds.filter((item) => item !== id);
    setSavedIds(updated);
    localStorage.setItem('nh_saved_notes', JSON.stringify(updated));
    window.dispatchEvent(new Event('nh:saved-notes-updated'));
  };

  const savedNotes = notes.filter((n) => savedIds.includes(n.id));

  if (savedNotes.length === 0) {
    return (
      <div className="nh-dim" style={{ textAlign: 'center', padding: '36px 12px' }}>
        <Bookmark style={{ width: 32, height: 32, margin: '0 auto 8px', opacity: 0.4 }} />
        <p style={{ margin: 0 }}>No saved notes yet.</p>
        <span style={{ fontSize: 12 }}>Click "Bookmark" on any notebook shelf to pin notes here.</span>
      </div>
    );
  }

  return (
    <div style={{ display: 'grid', gap: 12 }}>
      {savedNotes.map((note) => (
        <div
          key={note.id}
          className="shelf-item"
          style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}
          onClick={() => onOpenNote && onOpenNote(note)}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: 0 }}>
            <div style={{
              width: 38,
              height: 38,
              borderRadius: 10,
              background: 'linear-gradient(135deg, #ffd37a22, #8b7bff33)',
              border: '1px solid rgba(255,211,122,.3)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#ffd37a',
              flexShrink: 0
            }}>
              <FileText style={{ width: 18, height: 18 }} />
            </div>
            <div style={{ minWidth: 0 }}>
              <strong style={{ display: 'block', fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {note.title}
              </strong>
              <span className="nh-dim" style={{ fontSize: 12 }}>
                {note.subject} • {note.unit}
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
            <button
              className="pill pill-sm pill-primary"
              onClick={() => onOpenNote && onOpenNote(note)}
            >
              <BookOpen style={{ width: 13, height: 13, marginRight: 4 }} /> Read
            </button>
            <button
              className="pill pill-sm pill-ghost"
              title="Remove bookmark"
              onClick={(e) => removeBookmark(note.id, e)}
              style={{ padding: '7px 10px' }}
            >
              <Trash2 style={{ width: 13, height: 13, color: '#ff9aa8' }} />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
