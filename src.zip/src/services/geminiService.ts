import { GoogleGenAI } from '@google/genai';
import type { Note, ChatMessage } from '../types';

export const SYSTEM_PROMPT = `You are the NotesHub AI Study Assistant, an elite college Teaching Assistant and Senior Academic Tutor. You specialize in analyzing handwritten college lecture notes, laboratory observation journals, circuit schematics, physics/chemistry derivations, algorithms, and engineering calculations.

Your Core Directives:
1. Academic Rigor: Explain challenging concepts clearly, concisely, and with mathematical accuracy.
2. Lab Record Expertise: When answering questions regarding lab records, clarify experimental procedures, apparatus setup, observation formulas, unit conversions, and typical viva-voce questions.
3. Exam & Quiz Readiness: Formulate 3 insightful, exam-style practice questions with complete step-by-step answer keys when requested.
4. Mathematical Notation: Use clean LaTeX ($...$ for inline, $$...$$ for block formulas) and standard SI units.
5. Study Disclaimer: Remind students: "Study reference only. Verify calculations and lab steps independently prior to final submission."`;

export async function askGeminiStudyAssistant(
  userQuery: string,
  history: ChatMessage[],
  currentNote: Note | null,
  currentPage: number,
  totalPages: number,
  customApiKey?: string
): Promise<string> {
  const apiKey = customApiKey || import.meta.env.VITE_GEMINI_API_KEY;

  if (!apiKey) {
    return '⚠️ Gemini API Key not configured. Please add VITE_GEMINI_API_KEY to your .env file.';
  }

  // Construct contextual note header
  let contextBlock = '';
  if (currentNote) {
    contextBlock = `
[CURRENT CONTEXT - LECTURE NOTE / LAB RECORD]
Document Title: ${currentNote.title}
Subject: ${currentNote.subject}
Unit / Topic: ${currentNote.unit}
Semester: ${currentNote.semester || 'Sem 6'}
Document Type: ${currentNote.isLabRecord ? 'Laboratory Record / Practical Manual' : 'Handwritten Lecture Notes'}
Description: ${currentNote.description || 'None provided'}
Current Viewing Page: Page ${currentPage} of ${totalPages}
--------------------------------------------------
`;
  }

  const promptWithContext = `${contextBlock}Student Question: ${userQuery}`;

  try {
    const ai = new GoogleGenAI({ apiKey });
    
    // We format past messages for conversation memory
    const contents = [
      {
        role: 'user',
        parts: [{ text: `${SYSTEM_PROMPT}\n\n${promptWithContext}` }]
      }
    ];

    // Include recent history if available (up to 6 turns)
    const recentHistory = history.slice(-6);
    if (recentHistory.length > 0) {
      const historyContents = recentHistory.map((msg) => ({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      }));
      // Add current question
      historyContents.push({
        role: 'user',
        parts: [{ text: promptWithContext }]
      });

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: historyContents as any,
      });

      return response.text || 'No response generated.';
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents as any,
    });

    return response.text || 'No response received from Gemini.';
  } catch (err: any) {
    console.error('Gemini API Error via @google/genai:', err);

    // Fallback directly to REST API with gemini-1.5-flash or gemini-2.5-flash if SDK encounters model mapping differences
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
      const payload = {
        contents: [
          {
            parts: [
              { text: `${SYSTEM_PROMPT}\n\n${promptWithContext}` }
            ]
          }
        ]
      };

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error?.message || `HTTP ${res.status}`);
      }

      const data = await res.json();
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
      return text || 'No response received.';
    } catch (fallbackErr: any) {
      return `❌ Gemini AI Assistant Error: ${err.message || fallbackErr.message || 'Failed to connect'}. Please verify your Gemini API key in .env file.`;
    }
  }
}
