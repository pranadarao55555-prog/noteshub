import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './auth/AuthProvider';
import { PresenceProvider } from './context/PresenceContext';
import EntryExperience from './entry/EntryExperience';
import AccessStatusScreen from './auth/AccessStatusScreen';
import Gate from './auth/Gate';
import DashboardHome from './dashboard/DashboardHome';

export default function App() {
  return (
    <AuthProvider>
      <PresenceProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<EntryExperience />} />
            <Route path="/access" element={<AccessStatusScreen />} />
            <Route
              path="/dashboard"
              element={
                <Gate allow={['admin', 'approved']}>
                  <DashboardHome />
                </Gate>
              }
            />
          </Routes>
        </BrowserRouter>
      </PresenceProvider>
    </AuthProvider>
  );
}
