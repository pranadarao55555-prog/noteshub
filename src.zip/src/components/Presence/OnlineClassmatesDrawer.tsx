import React from 'react';
import { X, Users, BookOpen, Clock, ShieldCheck, UserPlus } from 'lucide-react';
import { usePresence } from '../../context/PresenceContext';
import { useAuth } from '../../context/AuthContext';
import type { PresenceUser } from '../../types';

function formatJoinedTime(timestamp: number): string {
  if (!timestamp) return 'Just now';
  const diff = Date.now() - timestamp;
  const seconds = Math.floor(diff / 1000);
  if (seconds < 60) return 'Just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h ago`;
}

export const OnlineClassmatesDrawer: React.FC = () => {
  const { 
    onlineUsers, 
    onlineCount, 
    isPresenceDrawerOpen, 
    setPresenceDrawerOpen, 
    simulateClassmatePresence 
  } = usePresence();
  const { currentUser, adminEmail } = useAuth();

  if (!isPresenceDrawerOpen) return null;

  // STRICT SORTING: The most recently joined user appears at the TOP of the list; earlier arrivals are shifted BELOW.
  const sortedUsers = [...onlineUsers].sort((a, b) => (b.joinedAt || 0) - (a.joinedAt || 0));

  return (
    <>
      {/* Backdrop overlay */}
      <div 
        className="fixed inset-0 bg-slate-950/50 backdrop-blur-[2px] z-40 transition-opacity"
        onClick={() => setPresenceDrawerOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-80 md:w-96 bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col animate-in slide-in-from-right duration-200 select-none">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <Users className="w-5 h-5" />
              </div>
              <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-slate-950 rounded-full animate-ping" />
              <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-slate-950 rounded-full" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">Online Classmates</h3>
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-mono">
                  {onlineCount} active
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Realtime presence • Cohort of 76
              </p>
            </div>
          </div>

          <button
            onClick={() => setPresenceDrawerOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Close drawer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Sorting Note Header with Arrival Simulator */}
        <div className="px-4 py-2 bg-slate-950/60 border-b border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>Recent arrivals at top</span>
          </div>

          <button
            onClick={() => simulateClassmatePresence()}
            className="text-[10px] font-semibold text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 px-2 py-0.5 rounded transition-all flex items-center gap-1"
            title="Simulate a new classmate joining to test sorting order"
          >
            <UserPlus className="w-2.5 h-2.5" />
            <span>+ Simulate Arrival</span>
          </button>
        </div>

      {/* Users List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {sortedUsers.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-xs">
            No other classmates online currently.
          </div>
        ) : (
          sortedUsers.map((user: PresenceUser) => {
            const isMe = user.uid === currentUser?.uid;
            const isAdmin = user.email.toLowerCase() === adminEmail.toLowerCase();

            return (
              <div
                key={user.uid}
                className={`p-3 rounded-xl border transition-all ${
                  isMe
                    ? 'bg-indigo-950/40 border-indigo-700/50 shadow-sm'
                    : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-start gap-3">
                  {/* Avatar */}
                  <div className="relative shrink-0">
                    <img
                      src={
                        user.photoURL ||
                        `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(
                          user.displayName || user.email
                        )}`
                      }
                      alt={user.displayName}
                      className="w-10 h-10 rounded-full border border-slate-700 object-cover bg-slate-800"
                    />
                    <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-slate-900 rounded-full" />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1.5 truncate">
                        <span className="text-xs font-semibold text-slate-200 truncate">
                          {user.displayName}
                        </span>
                        {isMe && (
                          <span className="text-[10px] font-medium text-indigo-400 bg-indigo-500/10 px-1.5 py-0.2 rounded">
                            You
                          </span>
                        )}
                        {isAdmin && (
                          <span className="text-[10px] font-medium text-amber-400 bg-amber-500/10 px-1.5 py-0.2 rounded flex items-center gap-0.5">
                            <ShieldCheck className="w-2.5 h-2.5" /> Admin
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1 text-[10px] text-slate-400 shrink-0 font-mono">
                        <Clock className="w-2.5 h-2.5" />
                        <span>{formatJoinedTime(user.joinedAt)}</span>
                      </div>
                    </div>

                    <div className="text-[11px] text-slate-400 truncate mt-0.5">
                      {user.email}
                    </div>

                    {/* Note being viewed currently */}
                    {user.currentNoteTitle && (
                      <div className="mt-2 flex items-center gap-1.5 text-[11px] text-indigo-300 bg-indigo-950/50 px-2 py-1 rounded-md border border-indigo-900/50 truncate">
                        <BookOpen className="w-3 h-3 shrink-0" />
                        <span className="truncate">Reading: {user.currentNoteTitle}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  </>
);
};
