import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Send, 
  Sparkles, 
  BookOpen, 
  HelpCircle, 
  Flame, 
  Calculator, 
  Check, 
  Copy, 
  Trash2, 
  Loader2, 
  Key, 
  GraduationCap 
} from 'lucide-react';
import { askGeminiStudyAssistant } from '../../services/geminiService';
import type { Note, ChatMessage } from '../../types';

interface GeminiAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentNote: Note | null;
  currentPage: number;
  totalPages: number;
}

export const GeminiAssistantDrawer: React.FC<GeminiAssistantDrawerProps> = ({
  isOpen,
  onClose,
  currentNote,
  currentPage,
  totalPages,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [customKey, setCustomKey] = useState<string>(() => {
    return localStorage.getItem('noteshub_gemini_key') || '';
  });
  const [showKeyInput, setShowKeyInput] = useState<boolean>(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSend = async (queryToSend?: string) => {
    const text = (queryToSend || inputQuery).trim();
    if (!text || loading) return;

    const userMessage: ChatMessage = {
      id: 'msg_' + Date.now(),
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputQuery('');
    setLoading(true);

    try {
      const response = await askGeminiStudyAssistant(
        text,
        messages,
        currentNote,
        currentPage,
        totalPages,
        customKey || undefined
      );

      const aiMessage: ChatMessage = {
        id: 'msg_ai_' + Date.now(),
        role: 'assistant',
        content: response,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, aiMessage]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: 'msg_err_' + Date.now(),
          role: 'assistant',
          content: `⚠️ Failed to get answer: ${err.message || 'Unknown error'}`,
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClear = () => {
    setMessages([]);
  };

  const saveCustomKey = (key: string) => {
    setCustomKey(key);
    localStorage.setItem('noteshub_gemini_key', key.trim());
    setShowKeyInput(false);
  };

  if (!isOpen) return null;

  return (
    <>
      <div 
        className="fixed inset-0 bg-slate-950/40 backdrop-blur-[2px] z-40 transition-opacity"
        onClick={onClose}
      />
      <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[480px] md:w-[540px] bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-600/30">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">Gemini Study Assistant</h3>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                AI TA
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Handwritten proof & lab analysis specialist
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowKeyInput(!showKeyInput)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Set Gemini API Key"
          >
            <Key className="w-4 h-4" />
          </button>
          {messages.length > 0 && (
            <button
              onClick={handleClear}
              className="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
              title="Clear Chat History"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Close Assistant"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* API Key Drawer Input */}
      {showKeyInput && (
        <div className="p-3 bg-slate-950/80 border-b border-slate-800">
          <label className="block text-[11px] font-medium text-slate-300 mb-1">
            Google Gemini API Key
          </label>
          <div className="flex gap-2">
            <input
              type="password"
              placeholder="AIzaSy..."
              value={customKey}
              onChange={(e) => setCustomKey(e.target.value)}
              className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-indigo-500"
            />
            <button
              onClick={() => saveCustomKey(customKey)}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition-colors"
            >
              Save Key
            </button>
          </div>
        </div>
      )}

      {/* Active Document Context Pill */}
      {currentNote && (
        <div className="px-4 py-2 bg-indigo-950/30 border-b border-indigo-900/40 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 truncate">
            <BookOpen className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span className="text-slate-300 truncate">
              {currentNote.subject} • {currentNote.title}
            </span>
          </div>
          <span className="text-[11px] font-mono text-indigo-300 shrink-0 ml-2">
            Page {currentPage} of {totalPages}
          </span>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="py-8 text-center">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto mb-3">
              <GraduationCap className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-semibold text-white mb-1">
              Ask anything about this document
            </h4>
            <p className="text-xs text-slate-400 max-w-xs mx-auto mb-6">
              I can explain difficult proofs, clarify lab observations, summarize formulas, or generate custom exam practice questions.
            </p>

            {/* Quick Action Suggestion Chips */}
            <div className="grid grid-cols-1 gap-2 text-left max-w-sm mx-auto">
              <button
                onClick={() =>
                  handleSend('Summarize all the key formulas and equations from this chapter in clean notation.')
                }
                className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-slate-200 text-xs text-left transition-all hover:border-indigo-500/50"
              >
                <Calculator className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Summarize key formulas and constants</span>
              </button>

              <button
                onClick={() =>
                  handleSend(
                    `Explain the core scientific concepts and derivations shown around page ${currentPage} in intuitive terms.`
                  )
                }
                className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-slate-200 text-xs text-left transition-all hover:border-indigo-500/50"
              >
                <HelpCircle className="w-4 h-4 text-sky-400 shrink-0" />
                <span>Explain current page concepts step-by-step</span>
              </button>

              <button
                onClick={() =>
                  handleSend(
                    'Quiz me with 3 challenging practice questions based on this note, and give detailed solutions after each.'
                  )
                }
                className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-slate-200 text-xs text-left transition-all hover:border-indigo-500/50"
              >
                <Flame className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Generate a 3-question revision quiz</span>
              </button>

              {currentNote?.isLabRecord && (
                <button
                  onClick={() =>
                    handleSend(
                      'Explain the lab apparatus, experimental methodology, observation calculations, and typical viva questions.'
                    )
                  }
                  className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-slate-200 text-xs text-left transition-all hover:border-indigo-500/50"
                >
                  <Sparkles className="w-4 h-4 text-violet-400 shrink-0" />
                  <span>Lab procedure, calculations & viva questions</span>
                </button>
              )}
            </div>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.role === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[90%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-indigo-600 text-white rounded-br-none'
                    : 'bg-slate-800/90 border border-slate-700 text-slate-200 rounded-bl-none shadow-sm'
                }`}
              >
                {/* Formatted Message Content */}
                <div className="whitespace-pre-wrap font-sans selection:bg-indigo-500/30">
                  {msg.content}
                </div>

                {/* Assistant footer with copy button */}
                {msg.role === 'assistant' && (
                  <div className="mt-2.5 pt-2 border-t border-slate-700/50 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="font-mono text-[10px]">Gemini 2.5 Flash</span>
                    <button
                      onClick={() => handleCopy(msg.id, msg.content)}
                      className="flex items-center gap-1 hover:text-white transition-colors"
                      title="Copy response"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}

        {loading && (
          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-800/60 border border-slate-700/50 text-indigo-300 text-xs w-fit">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Gemini AI is analyzing lecture notes...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Bar */}
      <div className="p-3 bg-slate-950 border-t border-slate-800">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder="Ask about equations, proofs, or lab questions..."
            className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-700/80 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
          />
          <button
            type="submit"
            disabled={!inputQuery.trim() || loading}
            className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white shadow-md shadow-indigo-600/30 transition-all hover:scale-105 active:scale-95"
            title="Send query"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  </>
);
};
