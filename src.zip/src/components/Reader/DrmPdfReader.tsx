import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import { 
  ChevronLeft, 
  ChevronRight, 
  ZoomIn, 
  ZoomOut, 
  Maximize, 
  Minimize, 
  RotateCw, 
  Sparkles, 
  ArrowLeft, 
  Loader2, 
  Shield, 
  AlertCircle 
} from 'lucide-react';
import { DisclaimerBanner } from '../Common/DisclaimerBanner';
import { SecurityToast } from '../Common/SecurityToast';
import { usePresence } from '../../context/PresenceContext';
import { getNoteBlobUrl } from '../../services/notesService';
import type { Note } from '../../types';

// Set static worker source to avoid bundling conflicts
pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.js';

interface DrmPdfReaderProps {
  note: Note;
  onClose: () => void;
  onOpenGemini: () => void;
  onPageChange?: (currentPage: number, totalPages: number) => void;
}

export const DrmPdfReader: React.FC<DrmPdfReaderProps> = ({
  note,
  onClose,
  onOpenGemini,
  onPageChange,
}) => {
  const { updateCurrentNoteViewing } = usePresence();

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const pdfDocRef = useRef<pdfjsLib.PDFDocumentProxy | null>(null);
  const renderTaskRef = useRef<any>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [numPages, setNumPages] = useState<number>(0);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [scale, setScale] = useState<number>(1.2);
  const [rotation, setRotation] = useState<number>(0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [securityAlert, setSecurityAlert] = useState<string | null>(null);
  const [renderProgress, setRenderProgress] = useState<boolean>(false);

  const onPageChangeRef = useRef(onPageChange);
  useEffect(() => {
    onPageChangeRef.current = onPageChange;
  }, [onPageChange]);

  const goToPrevPage = useCallback(() => {
    setCurrentPage((prev) => (prev > 1 ? prev - 1 : prev));
  }, []);

  const goToNextPage = useCallback(() => {
    setCurrentPage((prev) => (prev < numPages ? prev + 1 : prev));
  }, [numPages]);

  // Update presence status while viewing this note
  useEffect(() => {
    updateCurrentNoteViewing(note.id, note.title);
    return () => {
      updateCurrentNoteViewing();
    };
  }, [note.id, note.title, updateCurrentNoteViewing]);

  // Strict DRM Keyboard & Shortcut Interception
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isCtrlOrMeta = e.ctrlKey || e.metaKey;
      const key = e.key.toLowerCase();

      // Intercept Print (Ctrl+P / Cmd+P)
      if (isCtrlOrMeta && key === 'p') {
        e.preventDefault();
        e.stopPropagation();
        setSecurityAlert('Printing is strictly disabled. All note pages are DRM protected.');
        return false;
      }

      // Intercept Save / Download (Ctrl+S / Cmd+S)
      if (isCtrlOrMeta && key === 's') {
        e.preventDefault();
        e.stopPropagation();
        setSecurityAlert('Direct file downloads and saving are prohibited to prevent unauthorized distribution.');
        return false;
      }

      // Intercept View Source (Ctrl+U)
      if (isCtrlOrMeta && key === 'u') {
        e.preventDefault();
        e.stopPropagation();
        setSecurityAlert('Page source inspection is restricted.');
        return false;
      }

      // Intercept Copy (Ctrl+C / Cmd+C)
      if (isCtrlOrMeta && key === 'c') {
        e.preventDefault();
        e.stopPropagation();
        setSecurityAlert('Clipboard extraction is blocked on secure document pages.');
        return false;
      }

      // Intercept Developer Tools (F12 or Ctrl+Shift+I / Ctrl+Shift+J / Cmd+Option+I)
      if (
        e.key === 'F12' ||
        (isCtrlOrMeta && e.shiftKey && (key === 'i' || key === 'j' || key === 'c'))
      ) {
        e.preventDefault();
        e.stopPropagation();
        setSecurityAlert('Developer tools and DOM inspection are restricted.');
        return false;
      }

      // Arrow navigation
      if (key === 'arrowleft') {
        goToPrevPage();
      } else if (key === 'arrowright') {
        goToNextPage();
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      setSecurityAlert('Right-click context menu is disabled for protected lecture notes.');
      return false;
    };

    window.addEventListener('keydown', handleKeyDown, true);
    window.addEventListener('contextmenu', handleContextMenu, true);

    return () => {
      window.removeEventListener('keydown', handleKeyDown, true);
      window.removeEventListener('contextmenu', handleContextMenu, true);
    };
  }, [goToPrevPage, goToNextPage]);

  // Load PDF with HTTP Range Requests for resilient chunk streaming (>200MB - 500MB support)
  useEffect(() => {
    let isCancelled = false;

    const loadDocument = async () => {
      setLoading(true);
      setError(null);

      try {
        const streamUrl = await getNoteBlobUrl(note);

        // PDF.js configured with HTTP range requests and chunk streaming
        const loadingTask = pdfjsLib.getDocument({
          url: streamUrl,
          rangeChunkSize: 1048576, // 1MB chunks on demand
          disableAutoFetch: true,   // Never download entire 200MB+ file upfront
          disableStream: false,     // Stream progressive pages
          withCredentials: false,
        });

        const pdf = await loadingTask.promise;
        if (isCancelled) return;

        pdfDocRef.current = pdf;
        setNumPages(pdf.numPages);
        setCurrentPage(1);
        setLoading(false);

        if (onPageChangeRef.current) {
          onPageChangeRef.current(1, pdf.numPages);
        }
      } catch (err: any) {
        if (!isCancelled) {
          console.error('Failed to load PDF via range streaming:', err);
          setError(
            err.message || 'Failed to stream document. The file may be corrupt or range requests failed.'
          );
          setLoading(false);
        }
      }
    };

    loadDocument();

    return () => {
      isCancelled = true;
      if (renderTaskRef.current) {
        renderTaskRef.current.cancel();
      }
      if (pdfDocRef.current) {
        pdfDocRef.current.destroy();
      }
    };
  }, [note]);

  // Draw Discrete Signature Watermark onto the rendered Canvas
  const drawDynamicWatermark = useCallback(
    (ctx: CanvasRenderingContext2D, width: number, height: number) => {
      const dpr = window.devicePixelRatio || 1;
      ctx.save();
      // Ensure drawing operations operate in logical CSS coordinates with devicePixelRatio
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      ctx.font = '600 14px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
      ctx.fillStyle = 'rgba(140, 140, 140, 0.5)';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'bottom';

      // Positioned exactly 24px from right edge and 20px from bottom edge
      ctx.fillText('Notes by Pranada', width - 24, height - 20);

      ctx.restore();
    },
    []
  );

  // Render Page onto Canvas
  const renderPage = useCallback(
    async (pageNum: number) => {
      if (!pdfDocRef.current || !canvasRef.current) return;

      // Cancel previous page rendering if active
      if (renderTaskRef.current) {
        try {
          renderTaskRef.current.cancel();
        } catch {
          // ignore
        }
      }

      setRenderProgress(true);

      try {
        const page = await pdfDocRef.current.getPage(pageNum);
        const canvas = canvasRef.current;
        if (!canvas) return;

        const context = canvas.getContext('2d', { alpha: false });
        if (!context) return;

        const viewport = page.getViewport({ scale, rotation });
        const dpr = window.devicePixelRatio || 1;

        // Set high-DPI canvas buffer
        canvas.width = Math.floor(viewport.width * dpr);
        canvas.height = Math.floor(viewport.height * dpr);
        canvas.style.width = `${Math.floor(viewport.width)}px`;
        canvas.style.height = `${Math.floor(viewport.height)}px`;

        context.setTransform(dpr, 0, 0, dpr, 0, 0);

        // Render PDF page onto canvas
        const renderContext = {
          canvasContext: context,
          viewport: viewport,
        };

        const renderTask = page.render(renderContext);
        renderTaskRef.current = renderTask;

        await renderTask.promise;

        // Directly burn dynamic watermark into the canvas pixels
        drawDynamicWatermark(context, viewport.width, viewport.height);

        setRenderProgress(false);

        if (onPageChangeRef.current) {
          onPageChangeRef.current(pageNum, numPages);
        }
      } catch (err: any) {
        if (err?.name !== 'RenderingCancelledException') {
          console.error('Error rendering page:', err);
        }
        setRenderProgress(false);
      }
    },
    [scale, rotation, numPages, drawDynamicWatermark]
  );

  useEffect(() => {
    if (!loading && numPages > 0) {
      renderPage(currentPage);
    }
  }, [loading, currentPage, scale, rotation, renderPage, numPages]);

  // Re-render on window resize to ensure watermark and canvas scale stay cleanly aligned
  useEffect(() => {
    let timeoutId: number | undefined;
    const handleResize = () => {
      clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => {
        if (!loading && numPages > 0) {
          renderPage(currentPage);
        }
      }, 150);
    };

    window.addEventListener('resize', handleResize);
    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('resize', handleResize);
    };
  }, [loading, numPages, currentPage, renderPage]);

  const handleZoomIn = () => {
    setScale((prev) => Math.min(prev + 0.25, 3.0));
  };

  const handleZoomOut = () => {
    setScale((prev) => Math.max(prev - 0.25, 0.6));
  };

  const handleFitWidth = () => {
    if (containerRef.current) {
      const containerWidth = containerRef.current.clientWidth - 48;
      // standard page width ratio
      const estimatedScale = containerWidth / 612;
      setScale(Math.max(0.6, Math.min(estimatedScale, 2.5)));
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen().catch(console.error);
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(console.error);
      setIsFullscreen(false);
    }
  };

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-40 flex flex-col bg-slate-950 text-slate-100 select-none overflow-hidden"
      style={{
        userSelect: 'none',
        WebkitUserSelect: 'none',
      }}
      onContextMenu={(e) => {
        e.preventDefault();
        setSecurityAlert('Context menu is disabled on DRM protected material.');
      }}
    >
      {/* Persistent Disclaimer Banner */}
      <DisclaimerBanner />

      {/* Reader Navigation & Controls Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 backdrop-blur-md">
        {/* Document Info & Back */}
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors"
            title="Return to Notes Library"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Back</span>
          </button>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {note.subject}
              </span>
              {note.isLabRecord && (
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Lab Record
                </span>
              )}
            </div>
            <h2 className="text-sm font-semibold text-slate-100 truncate max-w-xs md:max-w-md">
              {note.title}
            </h2>
          </div>
        </div>

        {/* Page Jump & Navigation */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            onClick={goToPrevPage}
            disabled={currentPage <= 1 || loading}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-slate-200 transition-colors"
            title="Previous Page (Left Arrow)"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-1 text-xs font-mono px-2 py-1 bg-slate-950/60 rounded-md border border-slate-800">
            <input
              type="number"
              min={1}
              max={numPages || 1}
              value={currentPage}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                if (!isNaN(val) && val >= 1 && val <= numPages) {
                  setCurrentPage(val);
                }
              }}
              className="w-10 bg-transparent text-center font-bold text-indigo-300 focus:outline-none"
            />
            <span className="text-slate-500">/</span>
            <span className="text-slate-400">{numPages || '–'}</span>
          </div>

          <button
            onClick={goToNextPage}
            disabled={currentPage >= numPages || loading}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-slate-200 transition-colors"
            title="Next Page (Right Arrow)"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Zoom & Viewport Tools */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleZoomOut}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>

          <button
            onClick={handleFitWidth}
            className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors hidden sm:block"
            title="Fit to Width"
          >
            Fit
          </button>

          <span className="text-xs font-mono text-slate-400 w-12 text-center hidden sm:inline-block">
            {Math.round(scale * 100)}%
          </span>

          <button
            onClick={handleZoomIn}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>

          <button
            onClick={() => setRotation((r) => (r + 90) % 360)}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors hidden md:block"
            title="Rotate Page"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
            title="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </button>

          <div className="h-5 w-px bg-slate-800 mx-1" />

          {/* Ask Gemini AI Trigger Button */}
          <button
            onClick={onOpenGemini}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Sparkles className="w-4 h-4 text-amber-300 animate-spin-slow" />
            <span>Ask Gemini AI</span>
          </button>
        </div>
      </div>

      {/* Main Canvas Document Stage */}
      <div
        className="flex-1 relative overflow-auto flex items-center justify-center p-4 sm:p-6 bg-slate-950 select-none"
        onDragStart={(e) => e.preventDefault()}
      >
        {loading && (
          <div className="flex flex-col items-center justify-center gap-3 text-slate-400">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-400" />
            <div className="text-sm font-medium">Streaming Document Pages...</div>
            <div className="text-xs text-slate-500 font-mono">
              HTTP Range Requests • 1 MB dynamic chunks
            </div>
          </div>
        )}

        {error && (
          <div className="max-w-md p-6 bg-red-950/40 border border-red-800/60 rounded-2xl text-center">
            <AlertCircle className="w-10 h-10 text-red-400 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-red-200 mb-1">Failed to Stream Note</h3>
            <p className="text-xs text-slate-300 mb-4">{error}</p>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold rounded-lg transition-colors"
            >
              Back to Notes
            </button>
          </div>
        )}

        {/* Security watermark background badge */}
        {!loading && !error && (
          <div className="absolute top-4 left-4 z-10 pointer-events-none opacity-40 hover:opacity-100 transition-opacity">
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-900/80 border border-slate-800 rounded-full text-[10px] text-slate-400 font-mono">
              <Shield className="w-3 h-3 text-emerald-400" />
              <span>Canvas Direct Stream • No iFrame</span>
            </div>
          </div>
        )}

        {/* The single, strictly DRM-protected HTML5 Canvas */}
        <div
          className={`relative shadow-2xl rounded-sm transition-opacity duration-150 ${
            loading ? 'opacity-0' : 'opacity-100'
          }`}
          style={{
            boxShadow: '0 25px 60px -15px rgba(0, 0, 0, 0.9), 0 0 0 1px rgba(255, 255, 255, 0.05)',
          }}
        >
          {renderProgress && (
            <div className="absolute top-2 right-2 z-20 px-2 py-1 bg-slate-900/80 rounded text-[10px] text-indigo-300 font-mono flex items-center gap-1">
              <Loader2 className="w-3 h-3 animate-spin" /> Rendering...
            </div>
          )}
          <canvas
            ref={canvasRef}
            className="block max-w-none cursor-default bg-white"
            onContextMenu={(e) => {
              e.preventDefault();
              setSecurityAlert('Canvas extraction is blocked. Note identity is permanently watermarked.');
            }}
          />
        </div>
      </div>

      {/* Security alert toast */}
      {securityAlert && (
        <SecurityToast message={securityAlert} onClose={() => setSecurityAlert(null)} />
      )}
    </div>
  );
};
