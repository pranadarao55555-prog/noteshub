import { useState } from 'react';
import { useAuth } from '../auth/AuthProvider';

export default function LoginCard() {
  const { loginGoogle, loginEmail, error } = useAuth();
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [create, setCreate] = useState(false);
  const [busy, setBusy] = useState(false);

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    try {
      await fn();
    } catch {
      // handled in provider
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="nh-login glass-card" role="dialog" aria-label="Sign in to NotesHub">
      <h1 className="nh-logo">notes<span className="nh-dot" /></h1>
      <p className="nh-sub">{create ? 'Create your class account' : 'Sign in to open your class notes'}</p>
      <button className="pill pill-google" disabled={busy} onClick={() => run(loginGoogle)}>
        Continue with Google
      </button>
      <div className="nh-or"><span>or use email</span></div>
      <input
        className="field"
        type="email"
        placeholder="Email"
        autoComplete="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        className="field"
        type="password"
        placeholder="Password"
        autoComplete={create ? 'new-password' : 'current-password'}
        value={pw}
        onChange={(e) => setPw(e.target.value)}
      />
      {error && <p className="nh-error" role="alert">{error}</p>}
      <button
        className="pill pill-primary"
        disabled={busy || !email || !pw}
        onClick={() => run(() => loginEmail(email, pw, create))}
      >
        {create ? 'Create account' : 'Sign in'}
      </button>
      <button className="pill pill-ghost" onClick={() => setCreate((c) => !c)}>
        {create ? 'I already have an account' : 'New here? Request access'}
      </button>
    </div>
  );
}
